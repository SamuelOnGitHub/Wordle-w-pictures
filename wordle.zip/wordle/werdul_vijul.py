from function import funko, rules
import time, pygame, sys, random
from pygame.locals import *

#Pygame
pygame.init()
screen_width = 800
screen_height = 800
WINDOW = pygame.display.set_mode((screen_width,screen_height))
clock = pygame.time.Clock()

COLOUR1 = pygame.Color(random.randint(50,255), random.randint(50,255), random.randint(50,255))
print(COLOUR1)
####

words = []
length = 0

lingering = []


def textinput(text, x, y):
    for event in pygame.event.get():
        if event.type == KEYDOWN:
            if event.key == K_BACKSPACE:
                text = text[:-1]
            elif event.key == K_RETURN:
                return text, "no"
            elif chr(event.key).isalnum() or chr(event.key) == " ":
                print(event.key)
                print(chr(event.key))
                text += str(chr(event.key))
        elif event.type == QUIT:
            pygame.quit()
            sys.exit()
    i = 0
    j = 0
    for char in text:
        if char.isalnum():
            if i * 50 > 650:
                i = 0
                j += 1
            letter = pygame.image.load("letters/" + char + ".png")
            WINDOW.blit(letter, (x + (i*50), y + (j * 50)))
        i += 1
    i += 1
    return text, "yes"

def drawGrid(finkleberg):
    i = 0
    j = 0
    for item in finkleberg:
        if item[1] == "n":
            image = pygame.image.load("letters/"  + item[0] + "n.png")
            WINDOW.blit(image, (100 + (i*50), 100 + (j*50)))
            i += 1
        elif item[1] == "p":
            image = pygame.image.load("letters/"  + item[0] + "p.png")
            WINDOW.blit(image, (100 + (i*50), 100 + (j*50)))
            i += 1
        elif item[1] == "y":
            image = pygame.image.load("letters/"  + item[0] + "y.png")
            WINDOW.blit(image, (100 + (i*50), 100 + (j*50)))
            i += 1
        elif item[1] == 0:
            i = 0
            j += 1

def drawKeyboard(shattening):
    i = 0
    j = 0
    for item in shattening:
        if item == "0" or item == "-":
            i = 0
            j +=1
        elif shattening[item] == "n":
            image = pygame.image.load("letters/"  + item[0] + "n.png")
            WINDOW.blit(image, (100 + (i*50) + (j*25), 550 + (j*50)))
            i += 1
        elif shattening[item] == "y":
            image = pygame.image.load("letters/"  + item[0] + "y.png")
            WINDOW.blit(image, (100 + (i*50) + (j*25), 550 + (j*50)))
            i += 1
        elif shattening[item] == "p":
            image = pygame.image.load("letters/"  + item[0] + "p.png")
            WINDOW.blit(image, (100 + (i*50) + (j*25), 550 + (j*50)))
            i += 1
        elif shattening[item] == "u":
            image = pygame.image.load("letters/"  + item[0] + ".png")
            WINDOW.blit(image, (100 + (i*50) + (j*25), 550 + (j*50)))
            i += 1



alphabet = "qwertyuiop0asdfghjkl-zxcvbnm"
alphabettrue = {}
for a in alphabet:
    alphabettrue[a] = "u"


text = ""
solution = ""
guess = ""
grid = []
answered1 = False
loaded = False
wordChosen = False
finished = False
won = False
lost = False
guessed = False
gridUpdated = False
gaveUp = False
correct = False
rubItIn = False
round = 6
while True:
    clock.tick(60)
    WINDOW.fill(COLOUR1)
    if not answered1:
        image = pygame.image.load("letters/howlongword.png")
        WINDOW.blit(image, (100, 100))
        answer = textinput(text, 350, 300)
        text = answer[0]
        if answer[1] == "no":
            if text.isnumeric():
                if int(text) > 25 or int(text) < 1:
                    lingering.append(["letters/lengthmust.png", 180, 100, 350])
                    text = ""
                else:
                    answered1 = True

            else:
                lingering.append(["letters/invalid length.png", 180, 100, 350])
                text = ""
    else:
        length = int(text)
        if not loaded:
            with open("large.txt", "r") as file:
                wholefile = file.read().split()
                for w in wholefile:
                    if len(w) == length and w.isalpha():
                        words.append(w)
            loaded = True
        if not wordChosen:
            solution = words[random.randrange(0, len(words))]
            wordChosen = True
        if not finished:
            if guessed == False:

                answer = textinput(guess, 100, 400)
                guess = answer[0]
                if answer[1] == "no":
                    if guess == "give up":
                        finished = True
                        lost = True
                        gaveUp = True
                        guessed = True
                    elif len(guess) > length:
                        lingering.append(["letters/guesstoolong.png", 60, 400, 200])
                        guess = ""
                    elif len(guess) < length:
                        lingering.append(["letters/guesstooshort.png", 60, 400, 200])
                        guess = ""
                    elif guess not in words:
                        lingering.append(["letters/guessnotin.png", 60, 400, 200])
                        guess = ""
                    else:
                        guessed = True
            
            if not gridUpdated and guessed == True and guess != "give up":
                for c in range(0,len(guess)):
                    if guess[c] not in solution:
                        alphabettrue[guess[c]] = "n"
                        grid.append([guess[c], "n"])
                    if guess[c] in solution:
                        if guess[c] == solution[c]:
                            alphabettrue[guess[c]] = "y"
                            grid.append([guess[c], "y"])
                        else:
                            alphabettrue[guess[c]] = "p"
                            grid.append([guess[c], "p"])
                
                if guess == solution:
                    finished = True
                    won = True
                else:
                    round -= 1
                    if round == 0:
                        finished = True
                        lost = True
                
                grid.append([0,0])
                guess = ""
                gridUpdated = True
            

            guessed = False
            gridUpdated = False
        drawGrid(grid)
        drawKeyboard(alphabettrue)

        if won == True:
            image = pygame.image.load("letters/huzzah.png")
            WINDOW.blit(image, (400, 200))
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN:
                    text = ""
                    solution = ""
                    guess = ""
                    grid = []
                    answered1 = False
                    loaded = False
                    wordChosen = False
                    finished = False
                    won = False
                    lost = False
                    guessed = False
                    gridUpdated = False
                    gaveUp = False
                    correct = False
                    rubItIn = False
                    round = 6
                    for a in alphabet:
                        alphabettrue[a] = "u"
        elif lost == True:
            if rubItIn == False:
                for z in solution:
                    grid.append([z, "n"])
                rubItIn = True
            if gaveUp:
                image = pygame.image.load("letters/despair.png")
            else:
                image = pygame.image.load("letters/rats.png")
            WINDOW.blit(image, (400, 200))
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN:
                    text = ""
                    solution = ""
                    guess = ""
                    grid = []
                    answered1 = False
                    loaded = False
                    wordChosen = False
                    finished = False
                    won = False
                    lost = False
                    guessed = False
                    gridUpdated = False
                    gaveUp = False
                    correct = False
                    rubItIn = False
                    round = 6
                    for a in alphabet:
                        alphabettrue[a] = "u"

        


    removelinger = []
    for linger in lingering:
        if linger[1] < 0:
            removelinger.append(linger)
        else:
            image = pygame.image.load(linger[0])
            WINDOW.blit(image, (linger[2], linger[3]))
            linger[1] = linger[1] - 1
    for remove in removelinger:
        lingering.remove(remove)
    
    pygame.display.update()

